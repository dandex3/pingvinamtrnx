-- AlterTable
ALTER TABLE "Share" ADD COLUMN "name" TEXT;
