-- AlterTable
ALTER TABLE "Share" ADD COLUMN "removedReason" TEXT;
