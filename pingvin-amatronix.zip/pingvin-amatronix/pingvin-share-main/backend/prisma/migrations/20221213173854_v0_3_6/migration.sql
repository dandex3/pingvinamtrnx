-- AlterTable
ALTER TABLE "Share" ADD COLUMN "description" TEXT;
